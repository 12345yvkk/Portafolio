const canvasLogo = document.getElementById('logo');
const ctx = canvasLogo.getContext('2d');

const centro = canvasLogo.width / 2;
const radio = canvasLogo.width / 2;

const colorCirculo = '#ff5a36';
const colorLetra = '#101014';

ctx.beginPath();
ctx.arc(centro, centro, radio, 0, Math.PI * 2);
ctx.fillStyle = colorCirculo;
ctx.fill();

ctx.fillStyle = colorLetra;
ctx.font = 'bold 28px Verdana, Arial, sans-serif';
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.fillText('U', centro, centro + 1);
