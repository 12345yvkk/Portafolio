const canvasFondo = document.getElementById('fondo-adopta');
const ctx = canvasFondo.getContext('2d');

const colorFondo = '#fbf7ee';
const colorCirculo1 = '#2f6f5e';
const colorCirculo2 = '#f2a541';

function dibujarPatron() {
  const seccion = canvasFondo.parentElement;
  canvasFondo.width = seccion.clientWidth;
  canvasFondo.height = seccion.clientHeight;

  const ancho = canvasFondo.width;
  const alto = canvasFondo.height;

  ctx.fillStyle = colorFondo;
  ctx.fillRect(0, 0, ancho, alto);

  const separacion = 70;
  const radio = 18;
  let filaImpar = false;

  for (let y = radio; y < alto + separacion; y += separacion) {
    const desfase = filaImpar ? separacion / 2 : 0;
    ctx.fillStyle = filaImpar ? colorCirculo2 : colorCirculo1;

    for (let x = radio + desfase; x < ancho + separacion; x += separacion) {
      ctx.globalAlpha = 0.35;
      ctx.beginPath();
      ctx.arc(x, y, radio, 0, Math.PI * 2);
      ctx.fill();
    }
    filaImpar = !filaImpar;
  }
  ctx.globalAlpha = 1;
}

dibujarPatron();

window.addEventListener('resize', dibujarPatron);
