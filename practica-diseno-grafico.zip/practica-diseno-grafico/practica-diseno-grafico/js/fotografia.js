const canvasBanner = document.getElementById('banner');
const ctx = canvasBanner.getContext('2d');

const ancho = canvasBanner.width;  // 900
const alto = canvasBanner.height;  // 220

const colorFondoBanner = '#1c1c1c';
const colorTexto = '#f5f0e8';
const colorAcento = '#d4a24c';

ctx.fillStyle = colorFondoBanner;
ctx.fillRect(0, 0, ancho, alto);

ctx.fillStyle = colorAcento;
ctx.fillRect(0, alto - 8, ancho, 8);

ctx.fillStyle = colorTexto;
ctx.font = 'bold 48px Verdana, Arial, sans-serif';
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.fillText('Lente Estudio', ancho / 2, alto / 2 - 20);

ctx.fillStyle = colorAcento;
ctx.font = '22px Verdana, Arial, sans-serif';
ctx.fillText('Capturamos momentos, creamos marca', ancho / 2, alto / 2 + 30);
