function preparar(id) {
  const c = document.getElementById(id);
  const r = window.devicePixelRatio || 1;
  c.width = c.clientWidth * r;
  c.height = c.clientHeight * r;
  const ctx = c.getContext("2d");
  ctx.scale(r, r);
  return [ctx, c.clientWidth, c.clientHeight];
}

function circulo(ctx, x, y, radio, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, radio, 0, Math.PI * 2);
  ctx.fill();
}

// Recurso 1: fondo del encabezado (degradado + círculos)
function dibujarFondo() {
  const [ctx, w, h] = preparar("fondo-header");
  const g = ctx.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, "#4A2511");
  g.addColorStop(1, "#E07A2F");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  circulo(ctx, w * 0.85, h * 0.2, h * 0.7, "rgba(244,194,122,0.3)");
  circulo(ctx, w * 0.1, h, h * 0.6, "rgba(255,246,236,0.15)");
}

// Recurso 2: logotipo (círculo con iniciales)
function dibujarLogo() {
  const [ctx, w, h] = preparar("logo");
  circulo(ctx, w / 2, h / 2, w / 2, "#F4C27A");
  circulo(ctx, w / 2, h / 2, w / 2 - 3, "#FFF6EC");
  ctx.fillStyle = "#8B4513";
  ctx.font = "bold " + w * 0.38 + "px Georgia";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("DH", w / 2, h / 2);
}

// Recurso 3: ilustración de un pan
function dibujarPan() {
  const [ctx, w, h] = preparar("ilustracion");
  ctx.fillStyle = "#F4C27A"; // tabla
  ctx.beginPath();
  ctx.ellipse(w / 2, h * 0.75, w * 0.42, h * 0.1, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#B5591F"; // pan
  ctx.beginPath();
  ctx.ellipse(w / 2, h * 0.55, w * 0.34, h * 0.22, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#F4C27A"; // cortes
  ctx.lineWidth = 5;
  ctx.lineCap = "round";
  for (let i = -1; i <= 1; i++) {
    ctx.beginPath();
    ctx.moveTo(w / 2 + i * w * 0.13 - 10, h * 0.45);
    ctx.lineTo(w / 2 + i * w * 0.13 + 10, h * 0.6);
    ctx.stroke();
  }
}

function dibujarTodo() { dibujarFondo(); dibujarLogo(); dibujarPan(); }
window.addEventListener("load", dibujarTodo);
window.addEventListener("resize", dibujarTodo);
